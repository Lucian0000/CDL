/*Stan Lucian-Mihai 311CB*/
#include "main_header.h"

int main(void){
	char *query = (char *)calloc(LengthMax, sizeof(char));
	char *queryCopy = (char *)calloc(LengthMax, sizeof(char));

	int contor = 0, i, j;

	/*vector de cuvinte care retin cuvantul si in ce documente apare*/
	TWord *words = (TWord *)calloc(NrDoc, sizeof(TWord));
	
	printf("Introduceti query-ul\n");
	fgets(query, LengthMax, stdin);

	strncpy(queryCopy, query, strlen(query));

	/*extrag cuvintele din query*/	

	char *token = strtok(queryCopy, " ");
	while(token != NULL){
		if(token[0] != '&' && token[0] != '|' && token[0] != ' ') { 	
			if(search(clear(token), words, contor) == 0) {
				/*adaug cuvintele in vectorul de cuvinte*/
				adaug(words, clear(token), &contor);
				for(j = 0; j < NrDoc; j++) {
					FILE *in = fopen(build_string(j+1), "rt");
					size_t len = 0;
					ssize_t read;
					char *line = NULL;
					/*caut cuvintele in toate cele 20 de fisiere*/
					while ((read = getline(&line, &len, in)) != -1) {
	    				if(stristr(line, clear(token)) == 0) {
	    					/*marchez cu 1 fisierele in care am gasit*/
	    					words[contor-1].doc[j] = 1;
	    				}
	    			}
					fclose(in);
				}
			}
		}
		token = strtok(NULL, " ");
	}

	/*vector[i] retine apartia cuvantului in fisierul i*/
	int *vector = (int *)calloc(contor, sizeof(int));
	int *vector_doc_query = (int *)calloc(NrDoc, sizeof(int));
	/*construiec un vector cu rezultatele query-ului pentru fiecare fisier*/

	strncpy(queryCopy, query, strlen(query));

	function = (char *)calloc(LengthMax, sizeof(char));

	int numar_fisier = 0, characterCrt = 0, characterMax = strlen(query),
		contor_aux = 0, vector_contor = 0, rezultat = 0;
	for(; numar_fisier < NrDoc; numar_fisier++){
		for(i = 0; i < contor; i++) {
			vector[i] = words[i].doc[numar_fisier];			
		}
		vector_contor = 0; characterCrt = 0;
		characterMax = strlen(query);
		contor_aux = 0; characterCrt = 0;			
		/*fiecare query il convertesc la alta forma*/
		/*&& -> * */
		/*|| -> + */
		/*cuvantul il inlocuiesc cu 0 sau 1 daca exista sau nu */
		while(characterCrt < characterMax) {
			if(query[characterCrt] == '(' || query[characterCrt] == ')') {
				function[contor_aux] = query[characterCrt];
				contor_aux++; characterCrt++; /*trec peste ')' */
			}
			else if(is_case((const char)query[characterCrt]) ==1){
				function[contor_aux] = vector[vector_contor] + '0';
				vector_contor++; contor_aux++;
				while(is_case((const char)query[characterCrt]) == 1) characterCrt++;
				/*trec peste cuvant si il inlocuiesc cu 0 sau 1*/
			}
			else if(query[characterCrt] == '!'){
				characterCrt+=2;
				while(is_case((const char)query[characterCrt]) == 1) characterCrt++;
				function[contor_aux] = (vector[vector_contor]+1)%2 + '0';
				contor_aux++; characterCrt++;
				/*trec peste '!'*/
			}
			else if(query[characterCrt] == '&'){
				function[contor_aux] = '*';
				contor_aux++; characterCrt+=2;
				/*trec peste '&&*/
			}
			else if(query[characterCrt] == '|'){
				function[contor_aux] = '+';
				contor_aux++; characterCrt+=2;
				/*trec peste '||'*/
			}
			else characterCrt++; /*trec peste spatiu*/
		}
		function[contor_aux] = '\0';
		p=function;
		rezultat = eval(); /*calculez rezultatlul expresiei*/
		if(rezultat > 0) vector_doc_query[numar_fisier] = 1;
		else vector_doc_query[numar_fisier] = 0;
	}

	Afisare(vector_doc_query);

	/*eliberez memorie*/

	free(function);
	free(query);
	free(queryCopy);
	free(vector);
	free(vector_doc_query);

	for(i = 0; i < NrDoc; i++){
		free(words[i].word);
		free(words[i].doc);
	}
	free(words);
	return 0; 
}
