#include "main_header.h"

void adaug(TWord *words, char *local_string, int *contor) {
	/*aloc memorie pentru cuvant si pentru cele 20 de spatii in care retin
	daca exista in fisierul i cuvantul local_string*/
	words[*contor].doc = (int *)calloc(NrDoc, sizeof(int));
	words[*contor].word = (char *)calloc(LengthMax, sizeof(char));
	strcpy(words[*contor].word, local_string);
	(*contor)++;
}

int search(char *local_string, TWord *words, int counter) {
	/*caut folosind strcmp case-insensitive in vectorul de cuvinte*/
	if(counter == 0) return 0;
	for(int i = 0; i < counter; i++) {
		if(stricmp(local_string, words[i].word) == 0) return 1;
	}
	return 0;
}

char *build_string(int crt) {
	char *s = (char *)calloc(sizeof(char), 9);
	s[0] = 'd'; s[1] = 'o'; s[2] = 'c';
	if(crt < 10) {
		s[3] = '0';
		s[4] = crt + '0';
	}
	else {
		s[3] = crt / 10 + '0';
		s[4] = crt % 10 + '0';
	}
	s[5] = '.'; s[6] = 't'; s[7] = 'x'; s[8] = 't';
	return s;
}

int stricmp(char *str1, char *str2) {
	if(strlen(str1) != strlen(str2)) return strlen(str1) - strlen(str2);
	int i = 0, j = 0;
	for(i = 0; str1[i] != '\0'; i++) {
		if(str1[i] - str2[i] == 32 || str1[i] - str2[i] == -32 || 
			str1[i] - str2[i] == 0) j++;
		else 
			if(str1[i] < str2[i]) return -1;
			else return 1; 
	}
	return 0;
}

char to_lower(const unsigned char x) {
	if(x >= 'A' && x <= 'Z') return x - 32;
	return x;
}

int compare(const char *X, const char *Y){
	while(*X && *Y){
		if(to_lower((unsigned char)*X) != to_lower((unsigned char) *Y)) {
			return 0;
		}
		X++;
		Y++;
	}
	return (*Y == '\0');
}

int stristr(const char *X, const char *Y) {
	while (*X != '\0'){
		if((*X == *Y) && compare(X, Y))
			return 0;
		X++; 
	}
	return -1;
}

int is_case(const char x){
	if((x >= 'a' && x <= 'z') || (x >= 'A' && x <= 'Z')) return 1;
	return 0;
}

char *clear(const char *str) {
	char *rezultat = (char *)calloc(strlen(str), sizeof(char));
	int i = 0, nr_crt = 0;
	for(; str[i] != '\0'; i++) {
		if(is_case((const char)str[i])) rezultat[nr_crt++] = str[i]; 
	}
	rezultat[nr_crt] = '\0';		
	return rezultat;
}


int eval(){
	int r = termen();
	while(*p == '+' || *p == '-'){
		if(*p == '+') {
			p++;
			r=r+termen();
		}
		else{
			p++;
			r=r-termen();
		}
	}
	return r;
}

int termen(){
	int r = factor();
	while(*p == '*' || *p == '/') {
		if(*p == '*') {
			p++;
			r=r*factor();
		}
		else {
			p++;
			r=r/factor();
		}
	} 
	return r;
}
int factor(){
	int r = 0;
	if(*p == '(') {
		p++;
		r = eval();
		p++;
	}
	else{
		while(*p <= '9' && *p >= '0') {
			r = r*10 + (int)*p-'0';
			p++;
		}
	}
	return r;
}

void Afisare(int *vector_doc_query) {
	int numar_fisier;
	printf("[");
	for(numar_fisier=0; numar_fisier < NrDoc; numar_fisier++){
		if(numar_fisier==NrDoc-1)
			printf("%d", vector_doc_query[numar_fisier]);
		else 
			printf("%d ", vector_doc_query[numar_fisier]);
	}
	printf("]\n");
	printf("Fisierele care respecta query-ul sunt:\n");
	for(numar_fisier=0; numar_fisier < NrDoc; numar_fisier++){
		if(vector_doc_query[numar_fisier] == 1){
			printf("doc");
			if(numar_fisier + 1 > 9){
				printf("%d.txt\n", numar_fisier + 1);
			}
			else printf("0%d.txt\n", numar_fisier + 1);
		}
	}
}