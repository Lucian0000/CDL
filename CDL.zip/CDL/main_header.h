#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>

#define NrDoc 20
#define LengthMax 256

#ifndef _MHEADER_
#define _MHEADER_

typedef struct {
	char *word;
	int *doc;
}TWord;

char *function, *p;

/*Intoarce 1 sau 0 daca s-a gasit cuvantul sau nu*/
/*
	char *local_string = cuvantul de cautat
	TWord *words = vectorul de cuvinte
	counter = numarul de cuvinte curent
*/
int search(char *local_string, TWord *words, int counter);

/*Implementare strcmp cu case-insensitive*/
/*
	return 0 daca str1 = str2 lexicografic 
	return -1 daca str1 > str2 lexicografic
	return 1 daca str1 < str2 lexicografic
	toate conditiile se verifica case-insensitive
*/
int stricmp(char *str1, char *str2);

/*Implementare strstr case-insensitive*/
/*
	return 0 daca str1 = str2 lexicografic
	return -1 daca str1 != str2 lexicografic
	toate conditiile se verifica case-insensitive
*/
int stristr(const char *X,const char *Y);

/*functie ajutatoare pentru stristr*/
int compare(const char *X, const char *Y);

/*Adaug cuvantul in functie de rezultatul intors de functia search*/
/*
	Intoarce vectorul de cuvinte TWord *words modificat
	char *local_string = cuvantul pe care il adaug
	int *contor = pointer care retine numarul curent de cuvinte
*/
void adaug(TWord *words, char *local_string, int *contor);

/*Construieste string-ul pentru path*/
/*
	intoarece un char * in functie de fisierul curent
	int crt = numarul fisierului curent
*/
char *build_string(int crt);

/*functie de eliminare ( ) || && !*/
/*
	intoarce un string care contine doar litere
	const char *str string-ul construit prin strtok la inceputul algoritmului
*/
char *clear(const char *str);

/*functie de verificare daca caracterul x este litera sau nu*/
int is_case(const char x);

/*functie care interschimba litera mare cu litera mica in caz ca e nevoie*/
/*
	intoarce litera mica
*/
char to_lower(const unsigned char x);

/*functii pentru algoritmul de calculare a expresiei*/
int eval();
int termen();
int factor();

/*afisare*/
void Afisare(int *vector);

#endif